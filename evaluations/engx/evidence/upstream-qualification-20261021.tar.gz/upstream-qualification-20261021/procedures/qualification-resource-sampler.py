import json
import re
import time
from pathlib import Path

root = Path('/var/lib/local-ai/qualification/upstream-20261021')
stop = root / 'sampler.stop'
output = root / 'resource-samples.jsonl'
end = time.monotonic() + 28000
with output.open('a', buffering=1) as stream:
    while time.monotonic() < end and not stop.exists():
        sample = {'timestamp': time.time(), 'workers': [], 'gpu_metrics': []}
        phase = root / 'current-phase.json'
        if phase.exists():
            sample['phase'] = json.loads(phase.read_text())
        metrics = Path('/var/lib/local-ai/metrics/gpu.prom')
        if metrics.exists():
            sample['gpu_metric_age_seconds'] = time.time() - metrics.stat().st_mtime
            sample['gpu_metrics'] = [line for line in metrics.read_text().splitlines()
                                     if line.startswith(('aihost_gpu_vram_', 'aihost_gpu_temperature_max_', 'aihost_gpu_throttle_'))]
        for process in Path('/proc').iterdir():
            if not process.name.isdigit():
                continue
            try:
                if process.joinpath('comm').read_text().strip() != 'llama-server':
                    continue
                clients = {}
                for info in process.joinpath('fdinfo').iterdir():
                    text = info.read_text()
                    if 'drm-pdev:' not in text:
                        continue
                    fields = dict(line.split(':', 1) for line in text.splitlines() if line.startswith('drm-'))
                    identity = (fields.get('drm-pdev', '').strip(), fields.get('drm-client-id', '').strip())
                    clients[identity] = {key: value.strip() for key, value in fields.items()
                                         if any(term in key for term in ['resident', 'memory', 'total', 'pdev', 'client-id'])}
                sample['workers'].append({'pid': int(process.name), 'drm_clients': list(clients.values())})
            except (OSError, ValueError):
                pass
        sample['host_memory'] = {line.split(':')[0]: line.split(':')[1].strip()
                                 for line in Path('/proc/meminfo').read_text().splitlines()
                                 if line.split(':')[0] in ['MemAvailable', 'Cached', 'SwapFree', 'SwapTotal']}
        stream.write(json.dumps(sample) + '\n')
        time.sleep(5)
