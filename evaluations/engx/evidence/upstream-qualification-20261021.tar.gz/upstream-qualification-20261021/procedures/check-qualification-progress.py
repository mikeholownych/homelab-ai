import json
from pathlib import Path

root = Path('/home/mike/work/upstream-qualification-20261021')
observed = {}
for role in ['deep', 'lead']:
    for phase in ['baseline', 'candidate']:
        key = role + '-' + phase
        log = root / 'evidence' / (key + '.log')
        if not log.exists():
            continue
        lines = log.read_text().splitlines()
        observed[key] = {
            'completed_checks': sum(' PASS ' in line or ' FAIL ' in line for line in lines),
            'last_progress': lines[-3:],
            'completed_stages': [p.stem for p in (root / 'evidence' / key).glob('*.json')],
        }
main = (root / 'qualification-orchestration.log').read_text().splitlines()
print(json.dumps({'models': observed, 'orchestration': main[-5:]}, indent=2))
