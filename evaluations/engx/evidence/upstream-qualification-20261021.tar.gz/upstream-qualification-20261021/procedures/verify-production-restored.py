import json
import ssl
import sys
import urllib.request
from pathlib import Path
from datetime import datetime, timezone

def retain_failure(kind, value, traceback):
    Path('/home/mike/work/upstream-qualification-20261021/evidence/production-verification-error.json').write_text(
        json.dumps({'type': kind.__name__, 'message': str(value)[:500]}))
    sys.__excepthook__(kind, value, traceback)

sys.excepthook = retain_failure

base = 'https://10.0.8.5:8443'
context = ssl.create_default_context(cafile='/home/mike/.config/nexus/t5820-gateway-ca.crt')
urllib.request.install_opener(urllib.request.build_opener(urllib.request.ProxyHandler({}), urllib.request.HTTPSHandler(context=context)))
credentials = json.load(sys.stdin)
token = credentials['qualification']
headers = {'Authorization': 'Bearer ' + token, 'Content-Type': 'application/json'}
with urllib.request.urlopen(urllib.request.Request(base + '/v1/models', headers=headers), timeout=20) as response:
    models = json.load(response)['data']
results = []
for alias, expected_worker in [('engineering/lead', 'b0-live-llama-worker1'), ('engineering/deep', 'b0-live-llama-deep-worker2')]:
    description = next(m for m in models if m['id'] == alias)
    serving = description['serving']
    assert len(serving) == 1 and '5fc4f3c8c' in (serving[0].get('engine_version') or '')
    body = {'model': alias, 'messages': [{'role': 'user', 'content': 'Reply with the single word READY.'}],
            'max_tokens': 128, 'temperature': 0, 'stream': True}
    request = urllib.request.Request(base + '/v1/chat/completions', json.dumps(body).encode(),
                                     {**headers, 'X-AIHost-Reasoning': 'off'})
    answer = ''; finish = None
    with urllib.request.urlopen(request, timeout=120) as response:
        route = response.headers.get('X-AIHost-Route', '')
        assert expected_worker in route, route
        for line in response:
            text = line.decode().strip()
            if not text.startswith('data:') or text == 'data: [DONE]':
                continue
            event = json.loads(text[5:])
            for choice in event.get('choices') or []:
                answer += (choice.get('delta') or {}).get('content') or ''
                finish = choice.get('finish_reason') or finish
    assert answer.strip() == 'READY' and finish == 'stop', (alias, finish, {'answer_chars':len(answer), 'contains_ready':'READY' in answer, 'markup':any(s in answer for s in ['<think>', '</think>', '<|'])})
    results.append({'alias': alias, 'worker': expected_worker, 'ready_answer': True, 'finish': finish,
                    'engine_version': serving[0]['engine_version'], 'artifact_digest': serving[0]['artifact_digest']})
with urllib.request.urlopen(urllib.request.Request(base + '/health?strict=true', headers={'Authorization': 'Bearer ' + credentials['monitoring']}), timeout=20) as response:
    health = json.load(response)
assert health['ready'] and health['scheduler']['available_workers'] == 2
assert health['scheduler']['configured_workers'] == 2
assert all(w['drain']['state'] == 'active' for w in health['workers'].values())
print(json.dumps({'checked_at': datetime.now(timezone.utc).isoformat(), 'status': health['status'],
                  'scheduler': health['scheduler'], 'evidence': health['evidence'], 'smoke_results': results}))
