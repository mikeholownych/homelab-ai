"""Run matched runtime qualification without retaining model reasoning or replay text."""
import contextlib
import hashlib
import importlib
import json
import os
from pathlib import Path
import ssl
import statistics
import sys
import time
import urllib.request

SOURCE = Path('/home/mike/work/homelab-upstream-20261021')
WORK = Path('/home/mike/work/upstream-qualification-20261021')
sys.path.insert(0, str(SOURCE / 'evaluations/engx'))


def save(path, value):
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(value, indent=2))
    temporary.replace(path)


def main():
    role, phase, alias, expected_image, token_path = sys.argv[1:]
    budget = 8192 if role == 'lead' else 4096
    out = WORK / 'evidence' / f'{role}-{phase}'
    out.mkdir(parents=True, exist_ok=True)
    os.environ['ENGX_OUT'] = str(out)
    os.environ['ENGX_CORPUS'] = 'hard'
    os.environ['ENGX_PYTHON'] = '/home/mike/.local/share/aihost/reconcile/snapshot/.venv/bin/python'
    os.environ['QUALIFY_TRIALS'] = '3'
    os.environ['QUALIFY_REPLAYS'] = '20'
    os.environ['QUALIFY_MAX_TOKENS'] = str(budget + 8192)
    context = ssl.create_default_context(cafile='/home/mike/.config/nexus/t5820-gateway-ca.crt')
    urllib.request.install_opener(urllib.request.build_opener(urllib.request.ProxyHandler({}), urllib.request.HTTPSHandler(context=context)))
    qualify = importlib.import_module('qualify')
    engx = importlib.import_module('engx')
    engx.MAX_TOKENS = budget + 8192
    key = Path(token_path).read_text().strip()
    gateway = qualify.Gateway('https://10.0.8.5:8443', key, alias)
    description = gateway.describe()
    serving = description.get('serving') or []
    assert len(serving) == 1, 'Qualification alias must resolve to exactly one artifact'
    runtime_observation = json.loads((WORK / 'evidence' / f'{role}-{phase}-container.json').read_text())
    assert runtime_observation['image_name'].endswith('@' + expected_image), 'Unexpected runtime image identity'
    expected_code = '5fc4f3c8c' if phase == 'baseline' else '620d2225c'
    assert expected_code in (serving[0].get('engine_version') or ''), 'Unobserved or unexpected engine build'
    assert description['context_length'] == 65536
    assert (description.get('reasoning') or {}).get('budget') == budget
    identity = {'role': role, 'phase': phase, 'alias': alias, 'budget': budget,
                'started_at': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()), 'description': description,
                'container_observation': runtime_observation,
                'temperature': 0, 'tools_trials': 3, 'engineering_repeats': 1,
                'engineering_max_attempts': 3, 'corpus_digest': engx.corpus_digest(engx.TASKS),
                'replay_manifest_sha256': hashlib.sha256((WORK / 'replay-input-manifest.json').read_bytes()).hexdigest()}
    save(out / 'identity.json', identity)
    print('IDENTITY', role, phase, serving[0].get('engine_version'), expected_image, flush=True)
    bypasses = []
    original_post = gateway.post

    def checked_post(path, body, timeout=qualify.REQUEST_TIMEOUT):
        result = original_post(path, body, timeout=timeout)
        status, response, headers, elapsed = result
        if path == '/v1/chat/completions' and status == 200:
            normalized = {k.lower(): v for k, v in headers.items()}
            disposition = normalized.get('x-aihost-cache')
            assert disposition == 'BYPASS', 'Qualification received a cached completion'
            bypasses.append({'seconds': elapsed, 'cache': disposition})
        return result

    gateway.post = checked_post
    results = {}
    sessions = str(WORK / 'replay-inputs')
    for name, operation in [('tools', lambda: qualify.run_tools(gateway, sessions)),
                            ('contract-reasoning-on', lambda: qualify.run_contract(gateway)),
                            ('longctx', lambda: qualify.run_longctx(gateway, sessions, description))]:
        print('STAGE', role, phase, name, flush=True)
        stage_results = operation()
        results[name] = {'pass_rates': {k: round(qualify.rate(v), 3) for k, v in stage_results.items()}, 'results': stage_results}
        save(out / (name + '.json'), results[name])
    gateway.headers['X-AIHost-Reasoning'] = 'off'
    print('STAGE', role, phase, 'contract-reasoning-off', flush=True)
    rows = qualify.run_contract(gateway)
    results['contract-reasoning-off'] = {'pass_rates': {k: round(qualify.rate(v), 3) for k, v in rows.items()}, 'results': rows}
    save(out / 'contract-reasoning-off.json', results['contract-reasoning-off'])
    gateway.headers.pop('X-AIHost-Reasoning')
    print('STAGE', role, phase, 'engineering-outcomes', flush=True)
    engineering = []
    for task in engx.TASKS:
        record = engx.run_task(task, gateway.base, gateway.headers, alias, 3)
        for attempt in record.get('history', []):
            attempt.pop('response', None)
            attempt.pop('reasoning_tail', None)
        engineering.append(record)
        save(out / 'engineering.partial.json', {'identity': identity, 'results': engineering})
        print('ENGINEERING', role, phase, task['id'], 'PASS' if record['success'] else 'FAIL',
              'attempts', record['attempts'], 'seconds', record['wall_secs'], flush=True)
    success = [r for r in engineering if r['success']]
    outcome = {'task_count': len(engineering), 'validated_count': len(success),
               'validated_rate': len(success) / len(engineering),
               'mean_seconds_per_task': statistics.mean(r['wall_secs'] for r in engineering),
               'mean_tokens_per_task': statistics.mean(r['tokens'] for r in engineering),
               'per_task': {r['id']: r['success'] for r in engineering}}
    save(out / 'engineering.json', {'identity': identity, 'summary': outcome, 'results': engineering})
    summary = {'identity': identity, 'stages': {k: v['pass_rates'] for k, v in results.items()},
               'engineering': outcome, 'cache_bypass_observations': len(bypasses),
               'finished_at': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
    save(out / 'summary.json', summary)
    print('RESULT', role, phase, json.dumps(summary['stages']), json.dumps(outcome), flush=True)


if __name__ == '__main__':
    role, phase = sys.argv[1:3]
    log_dir = WORK / 'evidence'
    log_dir.mkdir(parents=True, exist_ok=True)
    with (log_dir / f'{role}-{phase}.log').open('a', buffering=1) as log:
        with contextlib.redirect_stdout(log), contextlib.redirect_stderr(log):
            try:
                main()
            except BaseException as error:
                print('FAILED', role, phase, type(error).__name__, str(error)[:400], flush=True)
                raise
