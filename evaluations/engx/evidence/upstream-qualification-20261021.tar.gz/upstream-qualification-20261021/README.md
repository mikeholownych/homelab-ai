# T5820 upstream qualification record

Completed physical runs: October 21, 2026. Final production verification: October 22, 2026.

Read [qualification.md](qualification.md) for findings, failure classes and limits. **No candidate promotion is justified.** Original runtimes were restored; the explicitly authorized gateway drain repair remains deployed.

The qualification branch includes the six reviewed implementation commits and this retained evidence. Embedded `published: false`, source HEADs and controller paths are historical observations captured before publication, not current branch metadata. `runtime/source-manifest.json` covers the six implementation commits against canonical main; the later evidence commit is outside that as-run manifest.

`procedures/` preserves the exact session procedures, including historical setup/repair steps and environment-specific absolute paths. They are an audit trail, not a turnkey rerun interface. Some procedures overwrite reports or change services: inspect and adapt deliberately before use. The completed run used the source workflow's drain guards, exclusive reconciliation lock and restoration blocks. No private keys, trust-store files, environment files, credential contents or raw replay sessions are included. Replay manifests contain hashes only.

`evidence-manifest.json` records the files in this published package. `runtime/historical-setup-production-verification-error.json` records an earlier setup failure; use `production-final-oct22.json` for final health.
