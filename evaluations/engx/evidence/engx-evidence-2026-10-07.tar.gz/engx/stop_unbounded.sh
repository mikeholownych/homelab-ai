#!/bin/bash
set -u
E=$HOME/engx; A=$E/evidence/UNBOUNDED_REASONING; mkdir -p $A
P() { sudo -n -u aihost-runtime env XDG_RUNTIME_DIR=/run/user/999 HOME=/var/lib/aihost-runtime sh -c 'cd /var/lib/aihost-runtime && exec podman "$@"' podman "$@"; }
date -u +%FT%TZ > $A/terminated_at.txt
cp $E/queue.txt $A/queue-remaining-at-termination.txt
# 1. stop the schedulers so they neither pull the next unbounded job nor restart production workers
for pid in $(pgrep -f "^/bin/bash .*runqueue.sh"); do kill $pid && echo "stopped scheduler $pid"; done
# 2. capture full server logs while the candidate containers still exist
for c in llama-cand0 llama-cand1; do P logs $c > $A/server-$c.log 2>&1; echo "$c log lines: $(wc -l < $A/server-$c.log)"; done
# 3. stop the in-flight unbounded harness runs (by pid, never by a pattern that matches this script)
for pid in $(pgrep -f "^python3 -I engx.py run t-"); do echo "killing $(tr '\0' ' ' < /proc/$pid/cmdline | cut -c1-80)"; kill $pid; done
sleep 3
for c in llama-cand0 llama-cand1; do P rm -f $c >/dev/null 2>&1 && echo "removed $c"; done
# 4. preserve per-run logs and the completed unbounded result
cp $E/logs/t-*.log $E/logs/server-t-*.log $A/ 2>/dev/null
cp $E/results/eng-hard-t-*.json $A/ 2>/dev/null
cp $E/logs/runqueue2-gpu*.log $A/
: > $E/queue.txt
ls -la $A | awk '{print $5, $9}'
pgrep -af "engx.py run|runqueue.sh" | grep -v pgrep || echo "no harness or scheduler processes left"
systemctl is-active aihost-llama-worker1 aihost-llama-worker2
