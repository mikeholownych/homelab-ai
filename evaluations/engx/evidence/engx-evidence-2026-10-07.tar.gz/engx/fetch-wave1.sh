#!/bin/bash
# Wave-1 candidate GGUFs, pinned to the HF revision seen at paper screen (2026-10-06).
set -u
H=~/.local/bin/hf; D=/var/lib/local-ai/models/gguf
get() { echo "== $(date -u +%FT%TZ) $1 @ $2 :: $3"; HF_HUB_ENABLE_HF_TRANSFER=1 $H download "$1" "$3" --revision "$2" --local-dir "$D/$4" || echo "!! FAILED $3"; }
get unsloth/Qwen3.8-27B-GGUF 4ca720788d1e Qwen3.8-27B-UD-Q4_K_M.gguf qwen3.8-27b
get meta-models/Muse-Glimmer-30B-GGUF 70bf1b61ac09 Muse-Glimmer-30B-KQuant-17GB-Q4_K_M.gguf muse-glimmer-30b
get unsloth/Qwen3.6-35B-A3B-GGUF a483e9e6cbd5 Qwen3.6-35B-A3B-UD-Q4_K_M.gguf qwen3.6-35b-a3b
get unsloth/GLM-4.7-Flash-GGUF 0d32489ecb9d GLM-4.7-Flash-Q4_K_M.gguf glm-4.7-flash
get ISTA-DASLab/Qwen3.8-Flash-Next-GSQ-RCO-Coder-GGUF 5348543e0147 IQ1_M/Qwen3.8-Flash-Next-GSQ-RCO-IQ1_M-00001-of-00002.gguf flashnext-gsq-coder
get ISTA-DASLab/Qwen3.8-Flash-Next-GSQ-RCO-Coder-GGUF 5348543e0147 IQ1_M/Qwen3.8-Flash-Next-GSQ-RCO-IQ1_M-00002-of-00002.gguf flashnext-gsq-coder
echo "== DONE $(date -u +%FT%TZ)"
