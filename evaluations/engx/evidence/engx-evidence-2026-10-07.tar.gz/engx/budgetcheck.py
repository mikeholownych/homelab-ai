import json, glob, os, sys
rows = []
for f in glob.glob(os.path.expanduser("~/engx/results/eng-hard-b-*.partial.json")):
    d = json.load(open(f))
    for r in d["results"]:
        for h in r["history"]:
            if "reasoning_tokens" in h:
                rows.append((d["label"], r["id"], h["attempt"], h["reasoning_tokens"], h["budget_reached"], h["valid_final_answer"], h["termination"], h["stage"]))
over = [x for x in rows if x[3] is not None and x[3] > 4096 + 16]
hit = [x for x in rows if x[4]]
print(f"attempts={len(rows)} budget_hits={len(hit)} over_budget={len(over)}")
for x in (over + hit)[:8]: print(x)
sys.exit(0 if (over or hit or len(rows) >= 40) else 1)
